---
name: Sentient Ops Light
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#424754'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#727785'
  outline-variant: '#c2c6d6'
  surface-tint: '#005ac2'
  primary: '#0058be'
  on-primary: '#ffffff'
  primary-container: '#2170e4'
  on-primary-container: '#fefcff'
  inverse-primary: '#adc6ff'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#4d5d73'
  on-tertiary: '#ffffff'
  tertiary-container: '#66768d'
  on-tertiary-container: '#fdfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  mono-data:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: -0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  container-margin: 24px
  gutter: 16px
---

## Brand & Style

This design system is engineered for high-stakes operational environments where clarity and data density are paramount. The aesthetic moves away from the traditional "dark mode" hacker tropes toward a sophisticated "clinical-technical" style. It evokes the feeling of a modern laboratory or an aerospace control center: bright, organized, and uncompromisingly precise.

The style is **Minimalist-Technical**. It leverages generous whitespace not just for aesthetics, but to create "breathing room" between dense data clusters. By utilizing a high-contrast light palette, it ensures maximum readability under various lighting conditions, maintaining a professional and authoritative tone that signals reliability and intelligence.

## Colors

The color strategy relies on a "High-Key" palette. The background is pure white to maximize the perceived brightness of the display. Primary actions and focal points use the signature blue (#3B82F6), which provides a sharp, vibrant contrast against the sterile white and grey surfaces.

Neutral tones follow a cool-grey scale (Slate), ranging from light background tints to deep charcoal for text. Use `surface_sunken` for layout containers like sidebars or table headers to provide structural definition without the need for heavy lines. Accent colors should be used sparingly—only to denote status, interactive states, or critical data points.

## Typography

This design system utilizes **Inter** exclusively to maintain a utilitarian and systematic feel. The type hierarchy is optimized for information density. 

The `mono-data` style should be applied to all numerical values, coordinates, and timestamps, utilizing Inter's tabular font features to ensure columns of numbers align perfectly. `label-caps` is the primary choice for metadata tags, table headers, and small UI descriptors, providing a clear visual distinction from body copy. High contrast between weights (Regular 400 vs SemiBold 600) is used to guide the eye through complex layouts.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid Grid**. Main navigation and sidebars are fixed-width to ensure tool accessibility, while the primary data stage is fluid. A strict 4px baseline grid governs all internal component spacing, ensuring that even the most data-dense views remain mathematically balanced.

Use `md` (16px) for standard padding within cards and modules. For high-density tables or "Operator Views," reduce internal padding to `sm` (8px). Margins between major sections should stay at `lg` (24px) to prevent the UI from feeling cluttered.

## Elevation & Depth

To maintain the clean, technical aesthetic, this design system avoids heavy shadows. Depth is communicated through **Tonal Layering** and **Low-Contrast Outlines**.

1.  **Level 0 (Floor):** Pure white (#FFFFFF). Used for the main canvas.
2.  **Level 1 (Surface):** Light grey (#F1F5F9). Used for sidebars, headers, and footer bars.
3.  **Level 2 (Object):** White cards with a subtle 1px border (#E2E8F0). No shadow.
4.  **Level 3 (Overlay):** Modals or dropdowns. These are the only elements allowed a shadow—a very soft, diffused ambient shadow (0px 10px 15px -3px rgba(0,0,0,0.05))—to indicate they are floating above the interface.

## Shapes

The shape language is **Soft-Technical**. A base radius of 4px (`rounded-sm`) is applied to buttons, input fields, and small containers. This slight rounding softens the "industrial" feel of the system without making it appear "consumer-soft" or playful. 

Larger containers like cards or panels may use `rounded-md` (8px) to clearly define them as structural boundaries. Interaction states (like focus rings) should follow the shape of the parent element precisely with a 2px offset.

## Components

- **Buttons:** Primary buttons use a solid #3B82F6 fill with white text. Secondary buttons use a transparent background with a #E2E8F0 border and #1E293B text. For "Operator Actions" within tables, use ghost buttons that only show a background tint on hover.
- **Input Fields:** Use a 1px #CBD5E1 border with a white background. On focus, the border changes to #3B82F6 with a subtle 2px blue glow (halo).
- **Data Chips:** Small, rectangular badges with a 2px radius. Use light tints of the status color (e.g., light blue background with dark blue text) to indicate categories without overwhelming the visual hierarchy.
- **Data Tables:** These are the heart of the design system. Use a subtle `surface_sunken` header row. Cell borders should be horizontal-only to encourage scanning. Row hovering should trigger a very light blue tint (#EFF6FF).
- **Status Indicators:** Use small, solid circles (6px) for "Live" status. "Online" is Primary Blue, "Warning" is Amber, and "Critical" is Red.
- **Terminal/Console:** Even in light mode, the console component should maintain a slightly darker, "blueprint" feel using a #1E293B background with light blue or white text to denote its separate functional nature.