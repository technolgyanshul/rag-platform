---
name: Sentient Ops
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#bec6e0'
  on-secondary: '#283044'
  secondary-container: '#3f465c'
  on-secondary-container: '#adb4ce'
  tertiary: '#bcc7de'
  on-tertiary: '#263143'
  tertiary-container: '#8691a7'
  on-tertiary-container: '#1f2a3c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#d8e3fb'
  tertiary-fixed-dim: '#bcc7de'
  on-tertiary-fixed: '#111c2d'
  on-tertiary-fixed-variant: '#3c475a'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  mono-code:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin: 24px
  container-max: 1600px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

This design system is engineered for technical operators managing high-consequence multi-agent RAG (Retrieval-Augmented Generation) environments. The aesthetic is rooted in **Modern Corporate** with a heavy emphasis on **Functional Utility**. It prioritizes information density and cognitive clarity over decorative elements.

The UI should evoke a sense of "Mission Control"—reliable, high-performance, and precise. It utilizes a structured card-based layout to compartmentalize complex agentic workflows, using subtle borders and a refined color theory to guide the eye through dense trace logs and performance scorecards. The emotional response is one of calm authority and technical mastery.

## Colors

The palette is anchored in a dark-mode-first environment to reduce eye strain during long-form monitoring. The primary "Tech Blue" is used sparingly for action items and active states. 

- **Foundation:** The background utilizes a deep slate (#020617), providing a high-contrast base for content containers.
- **Surfaces:** Secondary and Tertiary slates create a tiered hierarchy for cards and sidebars.
- **Accents:** Success (Emerald) and Warning (Amber) tones are saturated but used in small ratios (dots, thin borders, or labels) to ensure they signal urgency without cluttering the visual field.
- **Data Traces:** Different agents or data types should be distinguished by subtle variations in the blue-to-slate spectrum.

## Typography

This design system utilizes **Inter** for the primary interface to ensure maximum readability in data-dense tables and property panels. **Space Grotesk** is introduced for labels and monospaced content to provide a technical, futuristic edge that distinguishes "Machine Data" from "User Interface."

- **Hierarchy:** Use semi-bold weights for headers to maintain visibility against dark backgrounds.
- **Agent Traces:** All agent logs, JSON blobs, and unique IDs must use the `mono-code` style.
- **Labels:** Use `label-caps` for table headers and small metadata tags to create a clear structural distinction.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a maximum cap to ensure readability on ultra-wide monitor setups common in operations centers.

- **Grid System:** A 12-column grid is used for the main dashboard. Complex agent traces should occupy larger column spans (8-9), while telemetry sidebars occupy 3-4 columns.
- **Density:** This is a high-density system. Vertical spacing between table rows and list items is compressed (4px to 8px) to maximize the amount of "above-the-fold" information.
- **Margins:** Consistent 24px outer margins provide "breathing room" for the eyes, preventing the interface from feeling claustrophobic despite the high data density.

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Layering** rather than traditional shadows. Shadows are kept minimal to avoid "muddiness" in dark mode.

- **Surface Tiers:** The base level is the darkest. Cards sit one step higher (#0F172A). Overlays and modals sit at the highest level (#1E293B).
- **Subtle Borders:** Use 1px borders (#1E293B) to define card boundaries. This provides a "blueprint" feel that is sharper and more technical than soft shadows.
- **Interaction:** On hover, cards may increase their border brightness or apply a very subtle outer glow (0px 0px 8px) using the primary blue at 20% opacity.

## Shapes

The shape language is **Soft (0.25rem)**. This provides a professional, modern feel that avoids the "toy-like" appearance of highly rounded corners while remaining more accessible than harsh 0px corners.

- **Buttons & Inputs:** Use the standard 0.25rem (4px) radius.
- **Status Pills:** Use a full "pill" radius (999px) for status indicators (e.g., "Active", "Offline") to make them instantly recognizable as status tokens.
- **Cards:** Standard 4px radius, unless nested within a larger container, in which case they may remain sharp to emphasize the grid.

## Components

- **Buttons:** Primary buttons use a solid Tech Blue. Secondary buttons are "Ghost" style with a Slate border. Action icons within buttons should always be 16px.
- **Data Tables:** Row hover states are essential. Use a subtle background shift to #1E293B. Column headers should be sticky for long trace logs.
- **Agent Trace Cards:** These are the heart of the system. They should feature a header with the Agent ID (Mono), a timestamp, and a collapsible body containing the JSON or text response.
- **Scorecards:** Use "Sparklines" (mini-charts) inside small cards to show latency or token usage trends without requiring a full page transition.
- **Input Fields:** Dark background, 1px border. Focus state uses a 1px Primary Blue border and no outer glow.
- **Status Indicators:** A simple 8px dot combined with a `label-caps` text string. (Green = Healthy, Amber = High Latency, Red = Error).